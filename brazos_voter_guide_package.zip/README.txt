Brazos County Voter Guide - deployment notes

1. Extract this ZIP. It contains index.html.
2. Open index.html in a modern browser to test locally.
3. To publish, upload the extracted folder containing index.html to a static website host such as Netlify Drop or GitHub Pages.
4. Before sharing, follow the candidate campaign and official election links to verify current positions and ballot details.

This guide summarizes selected candidate priority summaries from https://theballotbrief.com/zip/77845. It is informational and nonpartisan, and it flags issues not explicitly covered in that source.
